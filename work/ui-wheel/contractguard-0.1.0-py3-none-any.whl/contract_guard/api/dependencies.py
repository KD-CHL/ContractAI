"""FastAPI dependency helpers for request scope and app services."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from fastapi import HTTPException, Request, status

from contract_guard.config import Settings
from contract_guard.services.cache import ReviewCache
from contract_guard.services.documents import DocumentService
from contract_guard.services.events import EventBus
from contract_guard.services.storage import ReviewRepository


@dataclass(frozen=True, slots=True)
class TenantScope:
    org_id: str
    session_id: str


def _scope_value(value: str | None, default: str, *, label: str) -> str:
    resolved = (value or default).strip()
    if not resolved:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"{label} cannot be empty",
        )
    if len(resolved) > 200 or any(ord(character) < 32 for character in resolved):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"{label} is invalid",
        )
    return resolved


def get_tenant_scope(request: Request) -> TenantScope:
    settings: Settings = request.app.state.settings
    headers = request.headers
    org_id = headers.get("x-org-id") or headers.get("x-organization-id")
    session_id = headers.get("x-session-id")
    return TenantScope(
        org_id=_scope_value(org_id, settings.default_org_id, label="X-Org-ID"),
        session_id=_scope_value(session_id, settings.default_session_id, label="X-Session-ID"),
    )


def get_repository(request: Request) -> ReviewRepository:
    return request.app.state.repository


def get_review_cache(request: Request) -> ReviewCache:
    return request.app.state.review_cache


def get_document_service(request: Request) -> DocumentService:
    return request.app.state.document_service


def get_event_bus(request: Request) -> EventBus:
    return request.app.state.event_bus


def get_review_workflow(request: Request) -> Any:
    return request.app.state.review_workflow
