"""FastAPI routes and transport schemas for ContractGuard."""

from contract_guard.api.routes import router

__all__ = ["router"]
