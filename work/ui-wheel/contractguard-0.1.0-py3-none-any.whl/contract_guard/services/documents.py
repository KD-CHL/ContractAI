"""Document ingestion and text extraction.

The service keeps binary parsing separate from the review workflow.  Image OCR
is deliberately represented by a small protocol so an on-premise model, a
hosted vision model, or a test double can be supplied without changing the API.
"""

from __future__ import annotations

import hashlib
import inspect
from collections.abc import Awaitable, Mapping
from dataclasses import dataclass, field
from io import BytesIO
from pathlib import Path
from typing import Any, Protocol, runtime_checkable


class DocumentError(ValueError):
    """Base class for errors safe to expose as a client input error."""


class DocumentTooLargeError(DocumentError):
    """Raised when an upload exceeds the configured limit."""


class UnsupportedDocumentTypeError(DocumentError):
    """Raised when a file is not one of the supported document formats."""


class DocumentParsingError(DocumentError):
    """Raised when a supported document cannot be decoded."""


@runtime_checkable
class VisionOCR(Protocol):
    """Injectable OCR boundary used for image and scanned-PDF extraction."""

    def extract_text(
        self,
        image: bytes,
        *,
        media_type: str,
        filename: str | None = None,
    ) -> str | Awaitable[str]: ...


@dataclass(frozen=True, slots=True)
class ParsedDocument:
    """Normalized result of document extraction."""

    text: str
    fingerprint: str
    filename: str
    media_type: str
    size_bytes: int
    page_count: int | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def character_count(self) -> int:
        return len(self.text)


_EXTENSION_MEDIA_TYPES = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".txt": "text/plain",
    ".md": "text/markdown",
    ".markdown": "text/markdown",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".tif": "image/tiff",
    ".tiff": "image/tiff",
    ".bmp": "image/bmp",
    ".gif": "image/gif",
    ".heic": "image/heic",
    ".heif": "image/heif",
}

_SUPPORTED_IMAGE_TYPES = {
    "image/png",
    "image/jpeg",
    "image/webp",
    "image/tiff",
    "image/bmp",
    "image/gif",
}

_GENERIC_MEDIA_TYPES = {"", "application/octet-stream", "binary/octet-stream"}


def document_fingerprint(content: bytes) -> str:
    """Return the stable SHA-256 identity of the original document bytes."""

    return hashlib.sha256(content).hexdigest()


def text_fingerprint(text: str) -> str:
    """Return a fingerprint for text submitted without a file."""

    return document_fingerprint(text.encode("utf-8"))


def _sniff_media_type(content: bytes) -> str | None:
    if content.startswith(b"%PDF-"):
        return "application/pdf"
    if content.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if content.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if content.startswith((b"II*\x00", b"MM\x00*")):
        return "image/tiff"
    if content.startswith(b"BM"):
        return "image/bmp"
    if content.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    if len(content) >= 12 and content[:4] == b"RIFF" and content[8:12] == b"WEBP":
        return "image/webp"
    return None


def _media_type_for(content: bytes, filename: str | None, declared_media_type: str | None) -> str:
    sniffed = _sniff_media_type(content)
    declared = (declared_media_type or "").split(";", 1)[0].strip().lower()
    suffix = Path(filename or "").suffix.lower()
    from_extension = _EXTENSION_MEDIA_TYPES.get(suffix)

    # Binary signatures take precedence over client-supplied headers. DOCX is a
    # ZIP container and is identified by its extension/content type below.
    if sniffed:
        return sniffed
    if declared not in _GENERIC_MEDIA_TYPES:
        return declared
    if from_extension:
        return from_extension
    return declared or "application/octet-stream"


def _decode_plain_text(content: bytes) -> str:
    if b"\x00" in content[:4096] and not content.startswith((b"\xff\xfe", b"\xfe\xff")):
        raise DocumentParsingError("the text document appears to contain binary data")
    for encoding in ("utf-8-sig", "utf-16", "gb18030"):
        try:
            return content.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise DocumentParsingError("the text document encoding is not supported")


def extract_pdf_text(content: bytes) -> tuple[str, int, dict[str, Any]]:
    """Extract searchable text from a PDF using PyMuPDF."""

    try:
        import fitz  # type: ignore[import-not-found]
    except ImportError as exc:  # pragma: no cover - dependency error path
        raise RuntimeError("PDF support requires the PyMuPDF package") from exc

    try:
        with fitz.open(stream=content, filetype="pdf") as pdf:
            page_text = [page.get_text("text").strip() for page in pdf]
            metadata = {
                str(key): value
                for key, value in (pdf.metadata or {}).items()
                if value not in (None, "")
            }
            return "\n\n".join(part for part in page_text if part), len(pdf), metadata
    except Exception as exc:
        raise DocumentParsingError("the PDF could not be parsed") from exc


def extract_docx_text(content: bytes) -> tuple[str, dict[str, Any]]:
    """Extract paragraphs and table cells from a DOCX document."""

    try:
        from docx import Document  # type: ignore[import-not-found]
    except ImportError as exc:  # pragma: no cover - dependency error path
        raise RuntimeError("DOCX support requires the python-docx package") from exc

    try:
        document = Document(BytesIO(content))
        blocks: list[str] = []
        blocks.extend(p.text.strip() for p in document.paragraphs if p.text.strip())
        for table in document.tables:
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                if any(cells):
                    blocks.append("\t".join(cells))

        properties = document.core_properties
        metadata = {
            key: value
            for key, value in {
                "title": properties.title,
                "subject": properties.subject,
                "author": properties.author,
                "keywords": properties.keywords,
            }.items()
            if value
        }
        return "\n".join(blocks), metadata
    except Exception as exc:
        raise DocumentParsingError("the DOCX document could not be parsed") from exc


class DocumentService:
    """Validate an uploaded document and turn it into reviewable text."""

    def __init__(
        self,
        *,
        vision_ocr: VisionOCR | None = None,
        max_bytes: int = 20 * 1024 * 1024,
    ) -> None:
        if max_bytes <= 0:
            raise ValueError("max_bytes must be greater than zero")
        self.vision_ocr = vision_ocr
        self.max_bytes = max_bytes

    async def parse(
        self,
        content: bytes,
        *,
        filename: str | None = None,
        media_type: str | None = None,
    ) -> ParsedDocument:
        if not content:
            raise DocumentParsingError("the uploaded document is empty")
        if len(content) > self.max_bytes:
            raise DocumentTooLargeError(
                f"the uploaded document exceeds the {self.max_bytes}-byte limit"
            )

        safe_name = Path(filename or "document").name or "document"
        resolved_type = _media_type_for(content, safe_name, media_type)
        metadata: dict[str, Any] = {}
        page_count: int | None = None

        if resolved_type == "application/pdf":
            text, page_count, metadata = extract_pdf_text(content)
            if not text and self.vision_ocr is not None:
                text = await self._ocr_pdf(content, safe_name)
        elif resolved_type == (
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        ) or safe_name.lower().endswith(".docx"):
            text, metadata = extract_docx_text(content)
            resolved_type = (
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )
        elif resolved_type in {"text/plain", "text/markdown"}:
            text = _decode_plain_text(content)
        elif resolved_type in _SUPPORTED_IMAGE_TYPES or resolved_type.startswith("image/"):
            text = await self._ocr_image(content, media_type=resolved_type, filename=safe_name)
            page_count = 1
        else:
            raise UnsupportedDocumentTypeError(f"unsupported document type: {resolved_type}")

        text = text.strip()
        if not text:
            raise DocumentParsingError("no reviewable text could be extracted")

        return ParsedDocument(
            text=text,
            fingerprint=document_fingerprint(content),
            filename=safe_name,
            media_type=resolved_type,
            size_bytes=len(content),
            page_count=page_count,
            metadata=metadata,
        )

    async def _ocr_image(self, content: bytes, *, media_type: str, filename: str | None) -> str:
        if self.vision_ocr is None:
            raise UnsupportedDocumentTypeError(
                "image documents require a configured VisionOCR implementation"
            )
        try:
            result = self.vision_ocr.extract_text(content, media_type=media_type, filename=filename)
            if inspect.isawaitable(result):
                result = await result
        except ValueError as exc:
            raise DocumentParsingError(str(exc)) from exc
        if not isinstance(result, str):
            raise DocumentParsingError("VisionOCR returned a non-text result")
        return result

    async def _ocr_pdf(self, content: bytes, filename: str) -> str:
        try:
            import fitz  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover - dependency error path
            raise RuntimeError("PDF support requires the PyMuPDF package") from exc

        extracted: list[str] = []
        try:
            with fitz.open(stream=content, filetype="pdf") as pdf:
                for page_number, page in enumerate(pdf, start=1):
                    pixmap = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
                    value = await self._ocr_image(
                        pixmap.tobytes("png"),
                        media_type="image/png",
                        filename=f"{filename}#page={page_number}",
                    )
                    if value.strip():
                        extracted.append(value.strip())
        except DocumentError:
            raise
        except Exception as exc:
            raise DocumentParsingError("the scanned PDF could not be OCR processed") from exc
        return "\n\n".join(extracted)


# Backwards-friendly name for callers that prefer a parser-oriented abstraction.
DocumentParser = DocumentService
