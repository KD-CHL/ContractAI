"""SQLite persistence with organization and session isolation.

The repository deliberately stores the domain report as JSON.  This keeps the
platform layer independent from the review model's implementation while still
supporting typed dataclasses and Pydantic models at the boundary.
"""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass, is_dataclass
from datetime import UTC, date, datetime
from enum import Enum, StrEnum
from pathlib import Path
from threading import RLock
from typing import Any, Protocol
from uuid import UUID, uuid4


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _json_default(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if hasattr(value, "dict") and callable(value.dict):
        return value.dict()
    if is_dataclass(value) and not isinstance(value, type):
        return asdict(value)
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, (set, frozenset, tuple)):
        return list(value)
    raise TypeError(f"value of type {type(value).__name__} is not JSON serializable")


def to_jsonable(value: Any) -> Any:
    """Convert common domain objects into detached JSON-compatible data."""

    return json.loads(json.dumps(value, default=_json_default, ensure_ascii=False))


def _encode_json(value: Any) -> str:
    return json.dumps(value, default=_json_default, ensure_ascii=False, separators=(",", ":"))


def _decode_object(value: str | None) -> dict[str, Any]:
    if not value:
        return {}
    decoded = json.loads(value)
    return decoded if isinstance(decoded, dict) else {"value": decoded}


def _validate_scope(org_id: str, session_id: str) -> None:
    if not org_id.strip():
        raise ValueError("org_id cannot be empty")
    if not session_id.strip():
        raise ValueError("session_id cannot be empty")


@dataclass(frozen=True, slots=True)
class StoredReview:
    id: str
    org_id: str
    session_id: str
    status: str
    fingerprint: str
    document_name: str
    media_type: str
    contract_id: str | None
    report: dict[str, Any]
    metadata: dict[str, Any]
    error: str | None
    created_at: datetime
    updated_at: datetime


@dataclass(frozen=True, slots=True)
class StoredFeedback:
    id: str
    review_id: str
    org_id: str
    session_id: str
    rating: int | None
    accepted: bool | None
    finding_id: str | None
    comment: str | None
    metadata: dict[str, Any]
    created_at: datetime


class MemoryLayer(StrEnum):
    """Supported memory horizons for review context and learning signals."""

    GLOBAL = "global"
    SHORT_TERM = "short_term"
    PROFILE = "profile"
    EPISODIC = "episodic"


@dataclass(frozen=True, slots=True)
class StoredMemory:
    id: str
    org_id: str
    session_id: str | None
    layer: MemoryLayer
    key: str
    content: Any
    metadata: dict[str, Any]
    created_at: datetime
    updated_at: datetime


class ReviewRepository(Protocol):
    def create_review(
        self,
        *,
        org_id: str,
        session_id: str,
        fingerprint: str,
        document_name: str,
        media_type: str,
        contract_id: str | None = None,
        metadata: Mapping[str, Any] | None = None,
        review_id: str | None = None,
        status: str = "processing",
    ) -> StoredReview: ...

    def get_review(
        self, review_id: str, *, org_id: str, session_id: str
    ) -> StoredReview | None: ...

    def upsert_memory(
        self,
        *,
        org_id: str,
        session_id: str | None,
        layer: MemoryLayer | str,
        key: str,
        content: Any,
        metadata: Mapping[str, Any] | None = None,
    ) -> StoredMemory: ...

    def list_memories(
        self,
        *,
        org_id: str,
        session_id: str | None,
        layer: MemoryLayer | str | None = None,
        limit: int = 100,
    ) -> Sequence[StoredMemory]: ...

    def update_review(
        self,
        review_id: str,
        *,
        org_id: str,
        session_id: str,
        status: str,
        report: Any | None = None,
        error: str | None = None,
    ) -> StoredReview | None: ...


class SQLiteReviewRepository:
    """Small, thread-safe repository backed by a single SQLite database."""

    def __init__(self, path: str | Path = "data/contractguard.db") -> None:
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
            self.path = str(Path(self.path).expanduser().resolve())
        self._lock = RLock()
        self._connection = sqlite3.connect(
            self.path,
            check_same_thread=False,
            isolation_level=None,
            timeout=10,
        )
        self._connection.row_factory = sqlite3.Row
        self._initialize()

    def _initialize(self) -> None:
        with self._lock:
            self._connection.execute("PRAGMA foreign_keys = ON")
            self._connection.execute("PRAGMA busy_timeout = 10000")
            if self.path != ":memory:":
                self._connection.execute("PRAGMA journal_mode = WAL")
            self._connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS reviews (
                    id TEXT PRIMARY KEY,
                    org_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    contract_id TEXT,
                    fingerprint TEXT NOT NULL,
                    document_name TEXT NOT NULL,
                    media_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    report_json TEXT NOT NULL DEFAULT '{}',
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    error TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_reviews_scope_id
                    ON reviews (org_id, session_id, id);
                CREATE INDEX IF NOT EXISTS idx_reviews_scope_fingerprint
                    ON reviews (org_id, session_id, fingerprint, updated_at DESC);

                CREATE TABLE IF NOT EXISTS review_feedback (
                    id TEXT PRIMARY KEY,
                    review_id TEXT NOT NULL,
                    org_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    rating INTEGER,
                    accepted INTEGER,
                    finding_id TEXT,
                    comment TEXT,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (review_id) REFERENCES reviews(id) ON DELETE CASCADE
                );

                CREATE INDEX IF NOT EXISTS idx_feedback_scope_review
                    ON review_feedback (org_id, session_id, review_id, created_at);

                CREATE TABLE IF NOT EXISTS memories (
                    id TEXT PRIMARY KEY,
                    org_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    layer TEXT NOT NULL CHECK (
                        layer IN ('global', 'short_term', 'profile', 'episodic')
                    ),
                    memory_key TEXT NOT NULL,
                    content_json TEXT NOT NULL,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE (org_id, session_id, layer, memory_key)
                );

                CREATE INDEX IF NOT EXISTS idx_memories_scope_layer
                    ON memories (org_id, session_id, layer, updated_at DESC);
                """
            )

    def close(self) -> None:
        with self._lock:
            self._connection.close()

    def __enter__(self) -> SQLiteReviewRepository:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def healthcheck(self) -> bool:
        try:
            with self._lock:
                value = self._connection.execute("SELECT 1").fetchone()
            return bool(value and value[0] == 1)
        except sqlite3.Error:
            return False

    def create_review(
        self,
        *,
        org_id: str,
        session_id: str,
        fingerprint: str,
        document_name: str,
        media_type: str,
        contract_id: str | None = None,
        metadata: Mapping[str, Any] | None = None,
        review_id: str | None = None,
        status: str = "processing",
    ) -> StoredReview:
        _validate_scope(org_id, session_id)
        if not fingerprint:
            raise ValueError("fingerprint cannot be empty")
        identifier = review_id or str(uuid4())
        now = _utc_now().isoformat()
        with self._lock:
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                self._connection.execute(
                    """
                    INSERT INTO reviews (
                        id, org_id, session_id, contract_id, fingerprint,
                        document_name, media_type, status, report_json,
                        metadata_json, error, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, '{}', ?, NULL, ?, ?)
                    """,
                    (
                        identifier,
                        org_id,
                        session_id,
                        contract_id,
                        fingerprint,
                        document_name,
                        media_type,
                        status,
                        _encode_json(dict(metadata or {})),
                        now,
                        now,
                    ),
                )
                self._connection.execute("COMMIT")
            except Exception:
                self._connection.execute("ROLLBACK")
                raise
        created = self.get_review(identifier, org_id=org_id, session_id=session_id)
        if created is None:  # pragma: no cover - protects repository invariant
            raise RuntimeError("created review could not be read back")
        return created

    def get_review(self, review_id: str, *, org_id: str, session_id: str) -> StoredReview | None:
        _validate_scope(org_id, session_id)
        with self._lock:
            row = self._connection.execute(
                """
                SELECT * FROM reviews
                WHERE id = ? AND org_id = ? AND session_id = ?
                """,
                (review_id, org_id, session_id),
            ).fetchone()
        return self._row_to_review(row) if row is not None else None

    def find_completed_by_fingerprint(
        self, fingerprint: str, *, org_id: str, session_id: str
    ) -> StoredReview | None:
        _validate_scope(org_id, session_id)
        with self._lock:
            row = self._connection.execute(
                """
                SELECT * FROM reviews
                WHERE fingerprint = ? AND org_id = ? AND session_id = ?
                  AND status = 'completed'
                ORDER BY updated_at DESC LIMIT 1
                """,
                (fingerprint, org_id, session_id),
            ).fetchone()
        return self._row_to_review(row) if row is not None else None

    def update_review(
        self,
        review_id: str,
        *,
        org_id: str,
        session_id: str,
        status: str,
        report: Any | None = None,
        error: str | None = None,
    ) -> StoredReview | None:
        _validate_scope(org_id, session_id)
        now = _utc_now().isoformat()
        report_json = _encode_json(report) if report is not None else None
        with self._lock:
            if report_json is None:
                cursor = self._connection.execute(
                    """
                    UPDATE reviews
                    SET status = ?, error = ?, updated_at = ?
                    WHERE id = ? AND org_id = ? AND session_id = ?
                    """,
                    (status, error, now, review_id, org_id, session_id),
                )
            else:
                cursor = self._connection.execute(
                    """
                    UPDATE reviews
                    SET status = ?, report_json = ?, error = ?, updated_at = ?
                    WHERE id = ? AND org_id = ? AND session_id = ?
                    """,
                    (
                        status,
                        report_json,
                        error,
                        now,
                        review_id,
                        org_id,
                        session_id,
                    ),
                )
        if cursor.rowcount == 0:
            return None
        return self.get_review(review_id, org_id=org_id, session_id=session_id)

    def delete_review(self, review_id: str, *, org_id: str, session_id: str) -> bool:
        _validate_scope(org_id, session_id)
        with self._lock:
            cursor = self._connection.execute(
                "DELETE FROM reviews WHERE id = ? AND org_id = ? AND session_id = ?",
                (review_id, org_id, session_id),
            )
        return cursor.rowcount > 0

    def add_feedback(
        self,
        review_id: str,
        *,
        org_id: str,
        session_id: str,
        rating: int | None = None,
        accepted: bool | None = None,
        finding_id: str | None = None,
        comment: str | None = None,
        metadata: Mapping[str, Any] | None = None,
        feedback_id: str | None = None,
    ) -> StoredFeedback | None:
        _validate_scope(org_id, session_id)
        if rating is not None and not 1 <= rating <= 5:
            raise ValueError("rating must be between 1 and 5")
        identifier = feedback_id or str(uuid4())
        created_at = _utc_now().isoformat()

        # The scoped INSERT ... SELECT prevents feedback from being attached to
        # another tenant's review even if its opaque id becomes known.
        with self._lock:
            cursor = self._connection.execute(
                """
                INSERT INTO review_feedback (
                    id, review_id, org_id, session_id, rating, accepted,
                    finding_id, comment, metadata_json, created_at
                )
                SELECT ?, id, org_id, session_id, ?, ?, ?, ?, ?, ?
                FROM reviews
                WHERE id = ? AND org_id = ? AND session_id = ?
                """,
                (
                    identifier,
                    rating,
                    None if accepted is None else int(accepted),
                    finding_id,
                    comment,
                    _encode_json(dict(metadata or {})),
                    created_at,
                    review_id,
                    org_id,
                    session_id,
                ),
            )
        if cursor.rowcount == 0:
            return None
        return StoredFeedback(
            id=identifier,
            review_id=review_id,
            org_id=org_id,
            session_id=session_id,
            rating=rating,
            accepted=accepted,
            finding_id=finding_id,
            comment=comment,
            metadata=dict(metadata or {}),
            created_at=datetime.fromisoformat(created_at),
        )

    def list_feedback(
        self, review_id: str, *, org_id: str, session_id: str
    ) -> Sequence[StoredFeedback]:
        _validate_scope(org_id, session_id)
        with self._lock:
            rows = self._connection.execute(
                """
                SELECT * FROM review_feedback
                WHERE review_id = ? AND org_id = ? AND session_id = ?
                ORDER BY created_at ASC
                """,
                (review_id, org_id, session_id),
            ).fetchall()
        return tuple(self._row_to_feedback(row) for row in rows)

    def list_obligations(
        self, review_id: str, *, org_id: str, session_id: str
    ) -> list[dict[str, Any]] | None:
        review = self.get_review(review_id, org_id=org_id, session_id=session_id)
        if review is None:
            return None
        value: Any = review.report.get("obligations", [])
        if isinstance(value, Mapping):
            value = value.get("items", [])
        if not isinstance(value, list):
            return []
        return [dict(item) if isinstance(item, Mapping) else {"value": item} for item in value]

    def upsert_memory(
        self,
        *,
        org_id: str,
        session_id: str | None,
        layer: MemoryLayer | str,
        key: str,
        content: Any,
        metadata: Mapping[str, Any] | None = None,
    ) -> StoredMemory:
        resolved_layer, scoped_session = _memory_scope(
            org_id=org_id, session_id=session_id, layer=layer
        )
        if not key.strip():
            raise ValueError("memory key cannot be empty")
        identifier = str(uuid4())
        now = _utc_now().isoformat()
        with self._lock:
            self._connection.execute(
                """
                INSERT INTO memories (
                    id, org_id, session_id, layer, memory_key, content_json,
                    metadata_json, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(org_id, session_id, layer, memory_key) DO UPDATE SET
                    content_json = excluded.content_json,
                    metadata_json = excluded.metadata_json,
                    updated_at = excluded.updated_at
                """,
                (
                    identifier,
                    org_id,
                    scoped_session,
                    resolved_layer.value,
                    key,
                    _encode_json(content),
                    _encode_json(dict(metadata or {})),
                    now,
                    now,
                ),
            )
        memory = self.retrieve_memory(
            key,
            org_id=org_id,
            session_id=session_id,
            layer=resolved_layer,
        )
        if memory is None:  # pragma: no cover - protects repository invariant
            raise RuntimeError("upserted memory could not be read back")
        return memory

    def retrieve_memory(
        self,
        key: str,
        *,
        org_id: str,
        session_id: str | None,
        layer: MemoryLayer | str,
    ) -> StoredMemory | None:
        resolved_layer, scoped_session = _memory_scope(
            org_id=org_id, session_id=session_id, layer=layer
        )
        with self._lock:
            row = self._connection.execute(
                """
                SELECT * FROM memories
                WHERE org_id = ? AND session_id = ? AND layer = ? AND memory_key = ?
                """,
                (org_id, scoped_session, resolved_layer.value, key),
            ).fetchone()
        return self._row_to_memory(row) if row is not None else None

    get_memory = retrieve_memory

    def list_memories(
        self,
        *,
        org_id: str,
        session_id: str | None,
        layer: MemoryLayer | str | None = None,
        limit: int = 100,
    ) -> Sequence[StoredMemory]:
        if limit <= 0 or limit > 1000:
            raise ValueError("limit must be between 1 and 1000")
        if layer is not None:
            resolved_layer, scoped_session = _memory_scope(
                org_id=org_id, session_id=session_id, layer=layer
            )
            query = """
                SELECT * FROM memories
                WHERE org_id = ? AND session_id = ? AND layer = ?
                ORDER BY updated_at DESC, id ASC LIMIT ?
            """
            parameters: tuple[Any, ...] = (
                org_id,
                scoped_session,
                resolved_layer.value,
                limit,
            )
        else:
            _validate_org(org_id)
            if session_id is None or not session_id.strip():
                query = """
                    SELECT * FROM memories
                    WHERE org_id = ? AND layer = 'global' AND session_id = ''
                    ORDER BY updated_at DESC, id ASC LIMIT ?
                """
                parameters = (org_id, limit)
            else:
                query = """
                    SELECT * FROM memories
                    WHERE org_id = ? AND (
                        (layer = 'global' AND session_id = '') OR
                        (layer != 'global' AND session_id = ?)
                    )
                    ORDER BY updated_at DESC, id ASC LIMIT ?
                """
                parameters = (org_id, session_id, limit)
        with self._lock:
            rows = self._connection.execute(query, parameters).fetchall()
        return tuple(self._row_to_memory(row) for row in rows)

    def delete_memory(
        self,
        key: str,
        *,
        org_id: str,
        session_id: str | None,
        layer: MemoryLayer | str,
    ) -> bool:
        resolved_layer, scoped_session = _memory_scope(
            org_id=org_id, session_id=session_id, layer=layer
        )
        with self._lock:
            cursor = self._connection.execute(
                """
                DELETE FROM memories
                WHERE org_id = ? AND session_id = ? AND layer = ? AND memory_key = ?
                """,
                (org_id, scoped_session, resolved_layer.value, key),
            )
        return cursor.rowcount > 0

    @staticmethod
    def _row_to_review(row: sqlite3.Row) -> StoredReview:
        return StoredReview(
            id=row["id"],
            org_id=row["org_id"],
            session_id=row["session_id"],
            status=row["status"],
            fingerprint=row["fingerprint"],
            document_name=row["document_name"],
            media_type=row["media_type"],
            contract_id=row["contract_id"],
            report=_decode_object(row["report_json"]),
            metadata=_decode_object(row["metadata_json"]),
            error=row["error"],
            created_at=datetime.fromisoformat(row["created_at"]),
            updated_at=datetime.fromisoformat(row["updated_at"]),
        )

    @staticmethod
    def _row_to_feedback(row: sqlite3.Row) -> StoredFeedback:
        accepted = row["accepted"]
        return StoredFeedback(
            id=row["id"],
            review_id=row["review_id"],
            org_id=row["org_id"],
            session_id=row["session_id"],
            rating=row["rating"],
            accepted=None if accepted is None else bool(accepted),
            finding_id=row["finding_id"],
            comment=row["comment"],
            metadata=_decode_object(row["metadata_json"]),
            created_at=datetime.fromisoformat(row["created_at"]),
        )

    @staticmethod
    def _row_to_memory(row: sqlite3.Row) -> StoredMemory:
        content = json.loads(row["content_json"])
        session_id = row["session_id"]
        return StoredMemory(
            id=row["id"],
            org_id=row["org_id"],
            session_id=session_id or None,
            layer=MemoryLayer(row["layer"]),
            key=row["memory_key"],
            content=content,
            metadata=_decode_object(row["metadata_json"]),
            created_at=datetime.fromisoformat(row["created_at"]),
            updated_at=datetime.fromisoformat(row["updated_at"]),
        )


def _validate_org(org_id: str) -> None:
    if not org_id.strip():
        raise ValueError("org_id cannot be empty")


def _memory_scope(
    *, org_id: str, session_id: str | None, layer: MemoryLayer | str
) -> tuple[MemoryLayer, str]:
    _validate_org(org_id)
    try:
        resolved_layer = MemoryLayer(layer)
    except ValueError as exc:
        allowed = ", ".join(item.value for item in MemoryLayer)
        raise ValueError(f"memory layer must be one of: {allowed}") from exc
    if resolved_layer is MemoryLayer.GLOBAL:
        return resolved_layer, ""
    if session_id is None or not session_id.strip():
        raise ValueError(f"session_id is required for {resolved_layer.value} memory")
    return resolved_layer, session_id


# Common implementation aliases retained for straightforward dependency wiring.
SQLiteStorage = SQLiteReviewRepository
ReviewStore = SQLiteReviewRepository
