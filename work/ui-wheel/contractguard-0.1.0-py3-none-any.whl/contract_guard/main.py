"""ContractGuard FastAPI application factory."""

from __future__ import annotations

import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from contract_guard.agent.workflow import ContractReviewWorkflow, ReviewDependencies
from contract_guard.api import router as api_router
from contract_guard.api.schemas import HealthResponse
from contract_guard.config import Settings, get_settings
from contract_guard.services.cache import InMemoryReviewCache, ReviewCache
from contract_guard.services.documents import DocumentService, VisionOCR
from contract_guard.services.events import EventBus, LocalEventBus
from contract_guard.services.knowledge import (
    LightRAGContextProvider,
    LocalKnowledgeContextProvider,
)
from contract_guard.services.memory import RepositoryMemoryContextProvider
from contract_guard.services.storage import ReviewRepository, SQLiteReviewRepository
from contract_guard.services.vision import OpenAIVisionOCR


def _default_workflow(
    settings: Settings,
    repository: ReviewRepository,
) -> ContractReviewWorkflow:
    local_knowledge = LocalKnowledgeContextProvider(settings.knowledge_path)
    knowledge_provider = local_knowledge
    if settings.app_mode == "hybrid" and settings.lightrag_base_url:
        knowledge_provider = LightRAGContextProvider(
            settings.lightrag_base_url,
            api_key=os.environ.get("LIGHTRAG_API_KEY"),
            fallback=local_knowledge,
        )
    memory_provider = RepositoryMemoryContextProvider(repository)
    if settings.llm_enabled:
        return ContractReviewWorkflow.with_openai(
            settings=settings,
            model=settings.openai_model,
            knowledge_provider=knowledge_provider,
            memory_provider=memory_provider,
        )
    return ContractReviewWorkflow(
        ReviewDependencies(
            knowledge_provider=knowledge_provider,
            memory_provider=memory_provider,
        )
    )


def create_app(
    *,
    settings: Settings | None = None,
    workflow: Any | None = None,
    review_workflow: Any | None = None,
    repository: ReviewRepository | None = None,
    storage: ReviewRepository | None = None,
    cache: ReviewCache | None = None,
    event_bus: EventBus | None = None,
    vision_ocr: VisionOCR | None = None,
    document_service: DocumentService | None = None,
) -> FastAPI:
    """Construct an application with replaceable platform dependencies."""

    resolved_settings = settings or get_settings()
    resolved_repository = repository or storage
    owns_repository = resolved_repository is None
    if resolved_repository is None:
        resolved_repository = SQLiteReviewRepository(resolved_settings.sqlite_path)

    resolved_workflow = (
        workflow
        or review_workflow
        or _default_workflow(
            resolved_settings,
            resolved_repository,
        )
    )
    resolved_cache = cache or InMemoryReviewCache(
        default_ttl_seconds=resolved_settings.cache_ttl_seconds
    )
    resolved_events = event_bus or LocalEventBus()
    resolved_vision_ocr = vision_ocr
    if document_service is None and resolved_vision_ocr is None and resolved_settings.llm_enabled:
        resolved_vision_ocr = OpenAIVisionOCR(
            model=resolved_settings.openai_model or "gpt-5.6-luna",
            base_url=resolved_settings.openai_base_url,
            timeout=resolved_settings.openai_timeout_seconds,
            max_retries=resolved_settings.openai_max_retries,
        )
    resolved_documents = document_service or DocumentService(
        vision_ocr=resolved_vision_ocr,
        max_bytes=resolved_settings.max_upload_bytes,
    )

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        yield
        if owns_repository:
            close = getattr(resolved_repository, "close", None)
            if callable(close):
                close()

    app = FastAPI(
        title=resolved_settings.app_name,
        version=resolved_settings.app_version,
        docs_url="/docs" if resolved_settings.docs_enabled else None,
        redoc_url="/redoc" if resolved_settings.docs_enabled else None,
        lifespan=lifespan,
    )
    app.state.settings = resolved_settings
    app.state.repository = resolved_repository
    app.state.review_cache = resolved_cache
    app.state.event_bus = resolved_events
    app.state.document_service = resolved_documents
    app.state.review_workflow = resolved_workflow

    @app.middleware("http")
    async def browser_security_headers(request: Request, call_next: Any) -> Response:
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault(
            "Permissions-Policy",
            "camera=(), microphone=(), geolocation=()",
        )
        if request.url.path == "/" or request.url.path.startswith("/ui-assets/"):
            response.headers.setdefault(
                "Content-Security-Policy",
                "default-src 'self'; script-src 'self'; style-src 'self'; "
                "img-src 'self' data:; connect-src 'self'; object-src 'none'; "
                "base-uri 'none'; frame-ancestors 'none'",
            )
        return response

    web_directory = Path(__file__).resolve().parent / "web"
    if web_directory.is_dir():
        app.mount(
            "/ui-assets",
            StaticFiles(directory=web_directory),
            name="ui-assets",
        )

        @app.get("/", include_in_schema=False)
        async def web_ui() -> FileResponse:
            return FileResponse(web_directory / "index.html")

    if resolved_settings.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=list(resolved_settings.cors_origins),
            allow_credentials=True,
            allow_methods=["GET", "POST", "PUT", "OPTIONS"],
            allow_headers=["Content-Type", "X-Org-ID", "X-Session-ID"],
        )

    @app.get(
        "/health",
        response_model=HealthResponse,
        tags=["system"],
        summary="Service health check",
    )
    async def health() -> HealthResponse:
        healthcheck = getattr(resolved_repository, "healthcheck", None)
        storage_ok = bool(healthcheck()) if callable(healthcheck) else True
        if not storage_ok:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="storage unavailable",
            )
        return HealthResponse(
            status="ok",
            service=resolved_settings.app_name,
            version=resolved_settings.app_version,
            environment=resolved_settings.environment,
            storage="ok",
            mode=resolved_settings.app_mode,
            ai_enabled=resolved_settings.llm_enabled,
            model=(resolved_settings.openai_model if resolved_settings.llm_enabled else None),
        )

    app.include_router(api_router, prefix=resolved_settings.api_prefix)
    return app


app = create_app()


__all__ = ["app", "create_app"]
