"use strict";

const MAX_FILE_BYTES = 20 * 1024 * 1024;
const REVIEW_TIMEOUT_MS = 180_000;
const SAMPLE_CONTRACT = `软件服务合同（演示）

第一条 服务期限
本合同有效期为十二个月。任一方未在到期前三十日书面通知终止的，本合同自动续期十二个月。

第二条 验收与付款
甲方应在收到交付成果后五个工作日内完成验收。期限内未提出书面异议的，视为验收合格。甲方必须在验收合格后十日内支付全部费用。

第三条 责任
因履行本合同产生的全部损失均由乙方承担，乙方承担无限责任。

第四条 合同变更
甲方有权根据业务需要随时单方修改服务内容及费用标准。`;

const RISK_LABELS = {
  critical: "严重风险",
  high: "高风险",
  medium: "中风险",
  low: "低风险",
  info: "提示",
};

const RISK_ORDER = { critical: 5, high: 4, medium: 3, low: 2, info: 1 };
const WARNING_TRANSLATIONS = {
  "LLM analysis was skipped; results are rule-based only.":
    "本次未调用 AI，结果来自本地规则与知识库。",
  "No evidence-backed risk finding was produced.":
    "本次没有生成具备合同原文证据的风险提示。",
};

const elements = {
  systemState: document.querySelector("#system-state"),
  systemStateText: document.querySelector("#system-state-text"),
  tabs: [...document.querySelectorAll(".input-tab")],
  textPanel: document.querySelector("#text-panel"),
  filePanel: document.querySelector("#file-panel"),
  contractText: document.querySelector("#contract-text"),
  characterCount: document.querySelector("#character-count"),
  contractFile: document.querySelector("#contract-file"),
  chooseFileButton: document.querySelector("#choose-file-button"),
  dropZone: document.querySelector("#drop-zone"),
  selectedFile: document.querySelector("#selected-file"),
  selectedFileName: document.querySelector("#selected-file-name"),
  selectedFileSize: document.querySelector("#selected-file-size"),
  removeFileButton: document.querySelector("#remove-file-button"),
  contractId: document.querySelector("#contract-id"),
  sampleButton: document.querySelector("#sample-button"),
  reviewButton: document.querySelector("#review-button"),
  progressCard: document.querySelector("#progress-card"),
  progressTitle: document.querySelector("#progress-title"),
  progressCopy: document.querySelector("#progress-copy"),
  progressSteps: [...document.querySelectorAll(".progress-steps li")],
  errorCard: document.querySelector("#error-card"),
  errorMessage: document.querySelector("#error-message"),
  retryButton: document.querySelector("#retry-button"),
  results: document.querySelector("#results"),
  resultsTitle: document.querySelector("#results-title"),
  resultSubtitle: document.querySelector("#result-subtitle"),
  modeNotice: document.querySelector("#mode-notice"),
  summaryFindings: document.querySelector("#summary-findings"),
  summaryHighest: document.querySelector("#summary-highest"),
  summaryHighRisk: document.querySelector("#summary-high-risk"),
  summaryObligations: document.querySelector("#summary-obligations"),
  summaryCoverage: document.querySelector("#summary-coverage"),
  findingList: document.querySelector("#finding-list"),
  riskFilters: document.querySelector("#risk-filters"),
  obligationSection: document.querySelector("#obligation-section"),
  obligationList: document.querySelector("#obligation-list"),
  contextDrawer: document.querySelector("#context-drawer"),
  contextCount: document.querySelector("#context-count"),
  contextList: document.querySelector("#context-list"),
  qualityPanel: document.querySelector("#quality-panel"),
  legalNotice: document.querySelector("#legal-notice"),
  printButton: document.querySelector("#print-button"),
  newReviewButton: document.querySelector("#new-review-button"),
};

const state = {
  mode: "text",
  selectedFile: null,
  activeRisk: "all",
  report: null,
  capabilities: null,
  progressTimer: null,
  sessionId: createSessionId(),
};

function createSessionId() {
  if (globalThis.crypto?.randomUUID) {
    return `web-${globalThis.crypto.randomUUID()}`;
  }
  return `web-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function createElement(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes)) return "未知大小";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function percent(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return "0%";
  return `${Math.round(Math.max(0, Math.min(1, numeric)) * 100)}%`;
}

async function loadHealth() {
  try {
    const response = await fetch("/health", { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error("health check failed");
    const health = await response.json();
    state.capabilities = health;
    elements.systemState.classList.remove("is-error");
    elements.systemState.classList.add("is-ready");
    elements.systemStateText.textContent = health.ai_enabled
      ? `AI 增强模式 · ${health.model || "已启用"}`
      : "本地审阅模式 · 服务正常";
  } catch {
    elements.systemState.classList.remove("is-ready");
    elements.systemState.classList.add("is-error");
    elements.systemStateText.textContent = "服务暂时不可用";
  }
}

function switchMode(mode, { focus = false } = {}) {
  state.mode = mode;
  elements.tabs.forEach((tab) => {
    const isActive = tab.dataset.mode === mode;
    tab.classList.toggle("is-active", isActive);
    tab.setAttribute("aria-selected", String(isActive));
    tab.tabIndex = isActive ? 0 : -1;
    if (focus && isActive) tab.focus();
  });
  elements.textPanel.hidden = mode !== "text";
  elements.filePanel.hidden = mode !== "file";
  clearError();
}

function updateCharacterCount() {
  elements.characterCount.textContent = `${elements.contractText.value.length.toLocaleString("zh-CN")} 字`;
}

function selectFile(file) {
  if (!file) return;
  if (file.size > MAX_FILE_BYTES) {
    showError("文件超过 20 MB。请压缩文件，或将合同文字复制到“粘贴合同”中。", false);
    return;
  }
  state.selectedFile = file;
  elements.selectedFileName.textContent = file.name || "未命名合同";
  elements.selectedFileSize.textContent = formatBytes(file.size);
  elements.dropZone.hidden = true;
  elements.selectedFile.hidden = false;
  clearError();
}

function clearSelectedFile() {
  state.selectedFile = null;
  elements.contractFile.value = "";
  elements.dropZone.hidden = false;
  elements.selectedFile.hidden = true;
}

function showError(message, allowRetry = true) {
  stopProgress();
  elements.errorMessage.textContent = message;
  elements.retryButton.hidden = !allowRetry;
  elements.errorCard.hidden = false;
  elements.results.hidden = true;
  elements.errorCard.scrollIntoView({ behavior: "smooth", block: "center" });
}

function clearError() {
  elements.errorCard.hidden = true;
  elements.errorMessage.textContent = "";
}

function startProgress() {
  clearError();
  elements.results.hidden = true;
  elements.progressCard.hidden = false;
  elements.reviewButton.disabled = true;
  const messages = [
    ["正在读取合同条款", "正在识别合同结构和关键表述。"],
    ["正在匹配风险", "正在对照规则、知识库和历史审阅偏好。"],
    ["正在核对原文证据", "每一条风险提示都必须能回到合同原文。"],
    ["正在整理审阅结果", "马上就好，正在排列风险优先级。"],
  ];
  let step = 0;
  updateProgressStep(step, messages);
  state.progressTimer = window.setInterval(() => {
    if (step < messages.length - 1) {
      step += 1;
      updateProgressStep(step, messages);
    }
  }, 1800);
}

function updateProgressStep(step, messages) {
  elements.progressTitle.textContent = messages[step][0];
  elements.progressCopy.textContent = messages[step][1];
  elements.progressSteps.forEach((item, index) => {
    item.classList.toggle("is-current", index === step);
    item.classList.toggle("is-complete", index < step);
  });
}

function stopProgress() {
  if (state.progressTimer !== null) {
    window.clearInterval(state.progressTimer);
    state.progressTimer = null;
  }
  elements.progressCard.hidden = true;
  elements.reviewButton.disabled = false;
}

function scopedHeaders(extra = {}) {
  return {
    "X-Org-ID": "local-web-ui",
    "X-Session-ID": state.sessionId,
    ...extra,
  };
}

async function parseResponse(response) {
  let payload = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }
  if (!response.ok) {
    throw new Error(normalizeApiError(response.status, payload));
  }
  return payload;
}

function normalizeApiError(status, payload) {
  if (status === 413) return "合同文件太大，请控制在 20 MB 以内。";
  if (status === 422) {
    const detail = payload?.detail;
    if (typeof detail === "string") return `合同无法读取：${detail}`;
    return "合同内容或文件格式无法识别，请换一个文件，或直接粘贴合同文字。";
  }
  if (status === 500 && state.capabilities?.ai_enabled) {
    return "AI 服务暂时无法连接。请检查网络后重试，或把 APP_MODE 改为 offline 使用本地审阅。";
  }
  const detail = payload?.detail;
  if (typeof detail === "string" && detail.trim()) return detail;
  if (detail && typeof detail === "object" && typeof detail.message === "string") {
    return detail.message;
  }
  return "服务暂时没有完成审阅，请稍后再试。";
}

async function submitReview() {
  const contractId = elements.contractId.value.trim();
  let request;
  if (state.mode === "text") {
    const text = elements.contractText.value.trim();
    if (!text) {
      showError("请先粘贴合同内容，或者点击“使用示例合同”。", false);
      elements.contractText.focus();
      return;
    }
    request = {
      url: "/api/v1/reviews/text",
      options: {
        method: "POST",
        headers: scopedHeaders({ "Content-Type": "application/json" }),
        body: JSON.stringify({
          text,
          contract_id: contractId || null,
          filename: "粘贴合同.txt",
          metadata: { source: "web_ui" },
        }),
      },
    };
  } else {
    if (!state.selectedFile) {
      showError("请先选择一份合同文件。", false);
      elements.chooseFileButton.focus();
      return;
    }
    const body = new FormData();
    body.append("file", state.selectedFile);
    if (contractId) body.append("contract_id", contractId);
    body.append("metadata", JSON.stringify({ source: "web_ui" }));
    request = {
      url: "/api/v1/reviews",
      options: { method: "POST", headers: scopedHeaders(), body },
    };
  }

  startProgress();
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), REVIEW_TIMEOUT_MS);
  try {
    const response = await fetch(request.url, { ...request.options, signal: controller.signal });
    const payload = await parseResponse(response);
    stopProgress();
    renderReview(payload);
  } catch (error) {
    const message =
      error?.name === "AbortError"
        ? "审阅等待时间过长。请检查服务和网络状态后重试。"
        : error?.message || "无法连接到审阅服务，请确认服务已经启动。";
    showError(message);
  } finally {
    window.clearTimeout(timeout);
  }
}

function renderReview(payload) {
  const report = payload?.report || {};
  state.report = report;
  state.activeRisk = "all";
  const findings = Array.isArray(report.findings) ? [...report.findings] : [];
  const obligations = Array.isArray(report.obligations) ? report.obligations : [];
  const contexts = Array.isArray(report.contexts) ? report.contexts : [];
  const quality = report.quality || {};

  findings.sort(
    (left, right) =>
      (RISK_ORDER[right.risk_level] || 0) - (RISK_ORDER[left.risk_level] || 0),
  );
  state.reportFindings = findings;

  const highRiskCount = findings.filter((item) =>
    ["critical", "high"].includes(item.risk_level),
  ).length;
  const highest = report.summary?.highest_risk_level;
  elements.summaryFindings.textContent = String(findings.length);
  elements.summaryHighest.textContent = highest
    ? `最高：${RISK_LABELS[highest] || highest}`
    : "未生成风险等级";
  elements.summaryHighRisk.textContent = String(highRiskCount);
  elements.summaryObligations.textContent = String(obligations.length);
  elements.summaryCoverage.textContent = percent(quality.evidence_coverage);

  elements.resultSubtitle.textContent = payload.cached
    ? "已使用同一会话中缓存的审阅结果。"
    : "以下内容均可回到合同原文核对。";
  renderModeNotice(Boolean(quality.llm_review_performed), findings.length);
  renderFindings(findings);
  renderObligations(obligations);
  renderContexts(contexts, quality, report.analysis_notes);

  const disclaimer = typeof report.disclaimer === "string" ? report.disclaimer : null;
  elements.legalNotice.textContent =
    disclaimer ||
    "本结果仅用于辅助定位合同问题，不构成法律意见，也不能代替了解交易背景的专业人员审阅。";

  elements.riskFilters.querySelectorAll("button").forEach((button) => {
    button.setAttribute("aria-pressed", String(button.dataset.risk === "all"));
  });
  elements.results.hidden = false;
  elements.resultsTitle.focus({ preventScroll: true });
  elements.results.scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderModeNotice(aiPerformed, findingCount) {
  elements.modeNotice.replaceChildren();
  const strong = createElement(
    "strong",
    "",
    aiPerformed ? "本次使用了 AI 增强审阅。" : "本次使用本地规则审阅。",
  );
  const detail = createElement(
    "span",
    "",
    findingCount === 0
      ? " 未发现当前规则或模型有原文证据支持的风险，但这不代表合同没有风险，仍需人工复核。"
      : " 所有展示的风险都经过合同原文证据核对。",
  );
  elements.modeNotice.append(strong, detail);
}

function renderFindings(findings) {
  elements.findingList.replaceChildren();
  const visible =
    state.activeRisk === "all"
      ? findings
      : findings.filter((finding) => finding.risk_level === state.activeRisk);
  if (visible.length === 0) {
    const empty = createElement("div", "empty-state");
    empty.append(
      createElement(
        "strong",
        "",
        findings.length === 0 ? "暂未发现有原文证据支持的风险提示" : "这个等级暂无风险提示",
      ),
      createElement(
        "span",
        "",
        findings.length === 0
          ? "这不代表合同没有风险，请继续由了解交易背景的专业人员复核。"
          : "可以切换到“全部”查看其他等级。",
      ),
    );
    elements.findingList.append(empty);
    return;
  }

  visible.forEach((finding, index) => {
    const risk = finding.risk_level || "info";
    const card = createElement("article", "finding-card");
    card.dataset.risk = risk;

    const main = createElement("div", "finding-main");
    const topline = createElement("div", "finding-topline");
    const titleGroup = createElement("div");
    titleGroup.append(
      createElement("p", "finding-index", `风险 ${index + 1}`),
      createElement("h4", "", finding.title || "需要进一步核对的条款"),
    );
    const chip = createElement("span", "risk-chip", RISK_LABELS[risk] || "风险提示");
    chip.dataset.risk = risk;
    topline.append(titleGroup, chip);
    main.append(topline);

    if (finding.description) {
      main.append(createElement("p", "finding-description", finding.description));
    }

    const evidence = Array.isArray(finding.evidence) ? finding.evidence : [];
    evidence.forEach((item) => {
      if (!item?.quote) return;
      const box = createElement("div", "evidence-box");
      box.append(
        createElement("span", "evidence-label", "合同原文"),
        createElement("blockquote", "", `“${item.quote}”`),
      );
      main.append(box);
    });
    card.append(main);

    if (finding.recommendation) {
      const recommendation = createElement("div", "recommendation-box");
      const copy = createElement("div", "recommendation-copy");
      copy.append(
        createElement("span", "recommendation-label", "建议关注"),
        createElement("p", "", finding.recommendation),
      );
      const copyButton = createElement("button", "copy-button", "复制建议");
      copyButton.type = "button";
      copyButton.addEventListener("click", () => copyRecommendation(copyButton, finding));
      recommendation.append(copy, copyButton);
      card.append(recommendation);
    }
    elements.findingList.append(card);
  });
}

async function copyRecommendation(button, finding) {
  const text = `${finding.title || "合同风险"}\n${finding.recommendation || ""}`.trim();
  try {
    await navigator.clipboard.writeText(text);
    button.textContent = "已复制";
  } catch {
    button.textContent = "复制失败";
  }
  window.setTimeout(() => {
    button.textContent = "复制建议";
  }, 1600);
}

function renderObligations(obligations) {
  elements.obligationList.replaceChildren();
  if (obligations.length === 0) {
    elements.obligationList.append(
      createElement(
        "div",
        "empty-state",
        "本次没有提取到明确的履行义务，请结合合同全文人工核对。",
      ),
    );
    return;
  }
  obligations.forEach((obligation) => {
    const card = createElement("article", "obligation-card");
    card.append(createElement("div", "obligation-party", obligation.obligor || "主体未明确"));
    const copy = createElement("div", "obligation-copy");
    copy.append(createElement("p", "", obligation.action || "义务内容需要核对"));
    const details = [obligation.due_expression, obligation.condition].filter(Boolean).join("；");
    if (details) copy.append(createElement("small", "", `时间或条件：${details}`));
    if (obligation.evidence?.quote) {
      copy.append(createElement("small", "", `原文：${obligation.evidence.quote}`));
    }
    card.append(copy);
    elements.obligationList.append(card);
  });
}

function renderContexts(contexts, quality, analysisNotes) {
  elements.contextList.replaceChildren();
  elements.contextCount.textContent = `${contexts.length} 条`;
  if (contexts.length === 0) {
    elements.contextList.append(
      createElement("div", "empty-state", "本次没有使用额外的知识库或历史记忆。"),
    );
  } else {
    contexts.forEach((context) => {
      const card = createElement("article", "context-card");
      const header = createElement("header");
      header.append(
        createElement("strong", "", context.citation || "审阅依据"),
        createElement(
          "span",
          "context-type",
          context.source === "memory" ? "历史偏好" : "知识库",
        ),
      );
      card.append(header, createElement("p", "", context.content || "无内容"));
      elements.contextList.append(card);
    });
  }

  elements.qualityPanel.replaceChildren();
  const qualityItems = [
    [quality.llm_review_performed ? "已调用" : "未调用", "AI 复核"],
    [String(quality.verified_finding_count ?? 0), "有原文证据的风险"],
    [percent(quality.completeness), "审阅流程完整度"],
  ];
  qualityItems.forEach(([value, label]) => {
    const item = createElement("div", "quality-item");
    item.append(createElement("strong", "", value), createElement("small", "", label));
    elements.qualityPanel.append(item);
  });

  const notes = [];
  if (Array.isArray(quality.warnings)) {
    quality.warnings.forEach((warning) => {
      const rejectedMatch = /^Rejected (\d+) finding/.exec(warning);
      if (rejectedMatch) {
        notes.push(`有 ${rejectedMatch[1]} 条缺少原文支持的候选风险已被自动剔除。`);
      } else {
        notes.push(WARNING_TRANSLATIONS[warning] || warning);
      }
    });
  }
  if (Array.isArray(analysisNotes)) {
    analysisNotes.forEach((note) => {
      if (typeof note === "string" && note.trim()) notes.push(note);
    });
  }
  if (notes.length > 0) {
    const noteBox = createElement("div", "analysis-notes");
    noteBox.append(createElement("strong", "", "审阅说明"));
    const list = createElement("ul");
    notes.forEach((note) => list.append(createElement("li", "", note)));
    noteBox.append(list);
    elements.qualityPanel.append(noteBox);
  }
}

function resetReview() {
  stopProgress();
  clearError();
  elements.results.hidden = true;
  state.report = null;
  window.scrollTo({ top: 0, behavior: "smooth" });
  window.setTimeout(() => {
    if (state.mode === "text") elements.contractText.focus();
    else elements.chooseFileButton.focus();
  }, 350);
}

elements.tabs.forEach((tab, index) => {
  tab.addEventListener("click", () => switchMode(tab.dataset.mode));
  tab.addEventListener("keydown", (event) => {
    if (!["ArrowLeft", "ArrowRight"].includes(event.key)) return;
    event.preventDefault();
    const nextIndex = event.key === "ArrowRight" ? (index + 1) % 2 : (index + 1) % 2;
    switchMode(elements.tabs[nextIndex].dataset.mode, { focus: true });
  });
});

elements.contractText.addEventListener("input", updateCharacterCount);
elements.sampleButton.addEventListener("click", () => {
  switchMode("text");
  elements.contractText.value = SAMPLE_CONTRACT;
  updateCharacterCount();
  elements.contractText.focus();
});
elements.chooseFileButton.addEventListener("click", () => elements.contractFile.click());
elements.contractFile.addEventListener("change", () => selectFile(elements.contractFile.files?.[0]));
elements.removeFileButton.addEventListener("click", clearSelectedFile);

["dragenter", "dragover"].forEach((eventName) => {
  elements.dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    elements.dropZone.classList.add("is-dragging");
  });
});
["dragleave", "drop"].forEach((eventName) => {
  elements.dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    elements.dropZone.classList.remove("is-dragging");
  });
});
elements.dropZone.addEventListener("drop", (event) => selectFile(event.dataTransfer?.files?.[0]));

elements.reviewButton.addEventListener("click", submitReview);
elements.retryButton.addEventListener("click", submitReview);
elements.printButton.addEventListener("click", () => window.print());
elements.newReviewButton.addEventListener("click", resetReview);
elements.riskFilters.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-risk]");
  if (!button || !state.reportFindings) return;
  state.activeRisk = button.dataset.risk;
  elements.riskFilters.querySelectorAll("button").forEach((item) => {
    item.setAttribute("aria-pressed", String(item === button));
  });
  renderFindings(state.reportFindings);
});

updateCharacterCount();
loadHealth();
